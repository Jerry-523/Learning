import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

class Fila {
    private final String[] buffer;
    private int cursor;
    private boolean isFull;
    private boolean isEmpty;

    public Fila() {
        buffer = new String[10];
        cursor = 0;
        isFull = false;
        isEmpty = true;
    }

    public synchronized void enqueue(String value) throws InterruptedException {
        while (isFull) {
            wait();
        }

        buffer[cursor] = value;
        cursor++;
        isEmpty = false;
        if (cursor == buffer.length) {
            isFull = true;
        }
        notify();
    }

    public synchronized String dequeue() throws InterruptedException {
        while (isEmpty) {
            wait();
        }

        String value = buffer[cursor - 1];
        cursor--;
        isFull = false;
        if (cursor == 0) {
            isEmpty = true;
        }
        notify();
        return value;
    }
}

class Docente implements Runnable {
    private final Fila fila;
    private final String[] nomesAlunos;
    private int count;

    public Docente(Fila fila, String[] nomesAlunos) {
        this.fila = fila;
        this.nomesAlunos = nomesAlunos;
        this.count = 0;
    }

    @Override
    public void run() {
        while (count < nomesAlunos.length) {
            try {
                synchronized (fila) {
                    fila.enqueue(nomesAlunos[count]);
                    fila.enqueue(nomesAlunos[count + 1]);
                    System.out.println("Prova Pronta!");
                    count += 2;
                }
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Aluno implements Runnable {
    private final Fila fila;

    public Aluno(Fila fila) {
        this.fila = fila;
    }

    @Override
    public void run() {
        while (true) {
            try {
                synchronized (fila) {
                    String nomeAluno = fila.dequeue();
                    System.out.println("Sou aluno: " + nomeAluno + " peguei a minha prova");
                }
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("Prova iniciada");
        System.out.println("Docente distribuindo as provas");
        String[] nomesAlunos = {"Pericles", "Marco", "Naomy", "Fabricia", "Silvano", "Denis", "Rafael", "Edmilson", "Amadeu", "Cesar"};
        Fila fila = new Fila();

        Thread docenteThread = new Thread(new Docente(fila, nomesAlunos));
        Thread[] alunoThreads = new Thread[nomesAlunos.length];

        for (int i = 0; i < nomesAlunos.length; i++) {
            alunoThreads[i] = new Thread(new Aluno(fila));
            alunoThreads[i].start();
        }

        docenteThread.start();
    }
}
